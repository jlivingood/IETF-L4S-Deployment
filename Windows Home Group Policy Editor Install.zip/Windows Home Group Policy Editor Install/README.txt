### Batch script method ###

1) CLick the Start Menu and type: gpedit.msc and hit Enter # You'll get an error if it's not installed
1) Right-click "group-policy-install.bat"
2) Select "Run as administrator"
3) screenshot popup window after the file completes
4) CLick the Start Menu and type: gpedit.msc and hit Enter # it should open the Group POlicy EDitor window now


### Manual method ###
# May get errors if you already ran the batch script, but I would like to see if the commands themselves are valid

1) Click the Windows start menu and type: cmd
2) select "Run as administrator"
3) In the Command Prompt window, type each of the following lines in seperately:

    FOR %F IN ("%SystemRoot%\servicing\Packages\Microsoft-Windows-GroupPolicy-ClientTools-Package~*.mum") DO (DISM /Online /NoRestart /Add-Package:"%F")
    FOR %F IN ("%SystemRoot%\servicing\Packages\Microsoft-Windows-GroupPolicy-ClientExtensions-Package~*.mum") DO (DISM /Online /NoRestart /Add-Package:"%F")

4) Screenshot the Command Prompt window when done
